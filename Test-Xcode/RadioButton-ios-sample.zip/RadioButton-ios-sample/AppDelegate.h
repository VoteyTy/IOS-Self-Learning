//
//  AppDelegate.h
//  RadioButtonSample
//
//  Created by Sergey on 9/22/13.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
